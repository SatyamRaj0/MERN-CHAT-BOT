// Mock backend for AI Chatbot (no OpenAI key needed)
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 5001;
const MONGO_URI = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/chatbotDB';

// connect mongo (optional, but kept for parity)
mongoose.connect(MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('✅ MongoDB connected (or available)'))
  .catch(err => console.warn('⚠️ MongoDB connection failed (it is optional for mock):', err.message));

// simple health
app.get('/', (req, res) => res.json({ status: 'ok', mode: 'mock' }));

// Mock chat route: returns canned responses with slight variations
app.post('/api/chat', (req, res) => {
  const { message, conversationId } = req.body || {};
  if (!message) return res.status(400).json({ error: 'message required' });

  // very simple "smart" mock: echo + transform + random tips
  const tips = [
    "💡 Quick tip: try asking for examples.",
    "🤖 I can help write code, summaries, or explain concepts.",
    "🧠 Pro tip: give context for better answers.",
    "🛠️ You can ask me to convert code between languages."
  ];
  const rand = tips[Math.floor(Math.random() * tips.length)];

  // create a mock reply
  const truncated = message.length > 80 ? message.slice(0, 80) + '...' : message;
  const reply = [
    `Sure — I read: "${message}". Here's a concise answer:`,
    `• Summary: ${truncated}`,
    '',
    `If you want more, try: "Explain in detail" or "Show code example".`,
    rand
  ].join('\n');

  console.log(`🗨️ Mock reply generated for message: ${truncated}`);

  // simulate processing delay (client shows typing)
  setTimeout(() => {
    res.json({ reply, conversationId: conversationId || null });
  }, 700 + Math.floor(Math.random() * 800));
});

app.listen(PORT, () => console.log(`🚀 Mock backend running on port ${PORT}`));
