Run: cd client && npm install && npm run dev
