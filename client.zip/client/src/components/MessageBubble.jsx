import React from 'react';
export default function MessageBubble({ msg }){
  const isUser = msg.role === 'user';
  return (
    <div className={`my-4 flex ${isUser ? 'justify-end' : 'justify-start'}`}>
      <div className={`${isUser ? 'bg-gradient-to-r from-indigo-500 to-purple-500 text-white' : 'bg-white/6 text-gray-100'} max-w-[70%] p-4 rounded-2xl shadow-lg`}>
        <div style={{whiteSpace:'pre-wrap'}}>{msg.content}</div>
      </div>
    </div>
  );
}
