    import React from 'react';
    export default function TypingDots(){
      return (
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 rounded-full bg-white/6 flex items-center justify-center">AI</div>
          <div className="bg-white/6 p-3 rounded">
            <div className="flex items-center gap-1">
              <span className="dot animate-pulse inline-block w-2 h-2 rounded-full bg-white"></span>
              <span className="dot animate-pulse inline-block w-2 h-2 rounded-full bg-white delay-150"></span>
              <span className="dot animate-pulse inline-block w-2 h-2 rounded-full bg-white delay-300"></span>
            </div>
          </div>
        </div>
);
    }
