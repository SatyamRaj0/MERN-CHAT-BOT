import React, { useEffect, useRef, useState } from 'react';
import axios from 'axios';
import { motion } from 'framer-motion';
import MessageBubble from './components/MessageBubble.jsx';
import TypingDots from './components/TypingDots.jsx';

const API_URL = import.meta.env.VITE_API_URL || "http://localhost:5001";

export default function App(){
  const [messages, setMessages] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem('chat_history_v1')) || [];
    } catch(e){ return []; }
  });
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef();

  useEffect(()=> {
    localStorage.setItem('chat_history_v1', JSON.stringify(messages));
    if(scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages]);

  const send = async () => {
    if(!input.trim()) return;
    const userMsg = { id: Date.now(), role:'user', content: input };
    setMessages(m => [...m, userMsg]);
    setInput('');
    setLoading(true);
    try {
      const res = await axios.post(`${API_URL}/api/chat`, { message: userMsg.content });
      const reply = res.data.reply || 'Sorry, no reply.';
      const botMsg = { id: Date.now()+1, role:'assistant', content: reply };
      // small delay to feel natural
      setTimeout(()=> setMessages(m => [...m, botMsg]), 400);
    } catch (err){
      console.error(err);
      const errMsg = { id: Date.now()+1, role:'assistant', content: 'Error: could not contact server.' };
      setMessages(m => [...m, errMsg]);
    } finally {
      setLoading(false);
    }
  };

  const clearChat = () => {
    setMessages([]);
    localStorage.removeItem('chat_history_v1');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0f172a] to-[#020617] text-white flex">
      <aside className="w-80 bg-black/40 backdrop-blur-md p-4 border-r border-white/5">
        <h2 className="text-2xl font-bold mb-2">💬 AI Chatbot</h2>
        <p className="text-sm text-gray-300 mb-4">Satyam Raj • Mock Mode</p>
        <button onClick={clearChat} className="w-full mb-2 bg-white/6 hover:bg-white/10 py-2 rounded">New Chat</button>
        <div className="text-xs text-gray-400 mt-4">Local: {API_URL}</div>
      </aside>

  <main className="flex-1 flex flex-col">
    <div className="flex-1 overflow-auto p-6" ref={scrollRef} style={{height: 'calc(100vh - 140px)'}}>
      <div className="max-w-3xl mx-auto">
        {messages.length===0 && <div className="text-center text-gray-400 mt-24">Start a conversation — ask anything.</div>}
        {messages.map(m => <MessageBubble key={m.id} msg={m} />)}
        {loading && <div className="mt-3"><TypingDots /></div>}
      </div>
    </div>

    <div className="p-4 border-t border-white/5 bg-gradient-to-t from-black/30">
      <div className="max-w-3xl mx-auto flex gap-3">
        <input value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>{ if(e.key==='Enter') send(); }} placeholder="Type your message (Enter to send)" className="flex-1 bg-white/6 placeholder-gray-300 rounded px-4 py-3 focus:outline-none" />
        <button onClick={send} className="bg-indigo-600 hover:bg-indigo-700 px-4 py-2 rounded">{loading ? '...' : 'Send'}</button>
      </div>
    </div>
  </main>
</div>
  );
}
